--
-- Database: `university`
--
CREATE DATABASE IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `university`;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_name` varchar(255) DEFAULT NULL,
  `course_number` varchar(10) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_name`, `course_number`, `id`) VALUES
('International Relations', 'BUS250', 326);

-- --------------------------------------------------------

--
-- Table structure for table `roster`
--

CREATE TABLE `roster` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roster`
--

INSERT INTO `roster` (`id`, `course_id`, `student_id`) VALUES
(1, 62, 16),
(2, 64, 23),
(3, 72, 30),
(4, 73, 30),
(5, 80, 37),
(6, 81, 37),
(7, 88, 44),
(8, 89, 44),
(9, 96, 51),
(10, 97, 51),
(11, 104, 58),
(12, 105, 58),
(13, 112, 65),
(14, 113, 65),
(15, 120, 72),
(16, 121, 72),
(17, 128, 79),
(18, 129, 79),
(19, 136, 86),
(20, 137, 86),
(21, 144, 93),
(22, 145, 93),
(23, 152, 100),
(24, 153, 100),
(25, 160, 107),
(26, 161, 107),
(27, 168, 114),
(28, 169, 114),
(29, 176, 121),
(30, 177, 121),
(31, 184, 128),
(32, 185, 128),
(33, 208, 149),
(34, 209, 149),
(35, 216, 156),
(36, 217, 156),
(37, 224, 163),
(38, 225, 163),
(39, 232, 170),
(40, 233, 170),
(41, 240, 177),
(42, 241, 177),
(43, 248, 184),
(44, 249, 184),
(45, 256, 191),
(46, 257, 191),
(47, 264, 198),
(48, 265, 198),
(49, 278, 214),
(50, 279, 214),
(51, 286, 221),
(52, 287, 221),
(53, 294, 228),
(54, 295, 228),
(55, 302, 235),
(56, 303, 235),
(57, 310, 242),
(61, 257, 326),
(62, 258, 327),
(63, 258, 328),
(64, 265, 335),
(65, 266, 336),
(66, 266, 337),
(67, 273, 344),
(68, 274, 345),
(69, 274, 346),
(70, 281, 353),
(71, 282, 354),
(72, 282, 355),
(73, 283, 362),
(74, 284, 363),
(75, 285, 363),
(76, 303, 374),
(77, 303, 374),
(78, 303, 374),
(79, 303, 374),
(80, 305, 376),
(81, 307, 376),
(82, 306, 376),
(83, 306, 376),
(84, 311, 379),
(85, 311, 379),
(86, 312, 379),
(87, 314, 379),
(88, 313, 379),
(89, 315, 379),
(90, 315, 379);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `name` varchar(255) DEFAULT NULL,
  `enroll_date` date DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `roster`
--
ALTER TABLE `roster`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=328;
--
-- AUTO_INCREMENT for table `roster`
--
ALTER TABLE `roster`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=384;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
